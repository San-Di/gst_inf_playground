#include <gst/gst.h>
int main(int argc, char *argv[]) {
    // Initialize GStreamer
    gst_init(&argc, &argv);
    test_yolo(0);

    GstElement *pipeline, *src, *fakesink;
    GstBus *bus;
    GstMessage *msg;
    
    // Create a new pipeline
    pipeline = gst_pipeline_new("audio-pipeline");

    // Create the elements
    src = gst_element_factory_make("audiotestsrc", "audio-source");
    fakesink = gst_element_factory_make("fakesink", "fake-sink");

    if (!pipeline || !src || !fakesink) {
        g_print("One or more elements could not be created. Exiting.\n");
        return -1;
    }

    // Set properties for audiotestsrc
    g_object_set(src, "num-buffers", 10, NULL);

    // Add elements to the pipeline
    gst_bin_add(GST_BIN(pipeline), src);
    gst_bin_add(GST_BIN(pipeline), fakesink);

    // Link the elements together
    if (gst_element_link(src, fakesink) != TRUE ) {
        g_print("Elements could not be linked. Exiting.\n");
        gst_object_unref(pipeline);
        return -1;
    }

    // Set fakesink's "sync" property to false
    g_object_set(fakesink, "sync", false, NULL);

    // Set the pipeline to the PLAYING state
    gst_element_set_state(pipeline, GST_STATE_PLAYING);

    // Wait until error or EOS
    bus = gst_element_get_bus(pipeline);
    msg = gst_bus_timed_pop_filtered(bus, GST_CLOCK_TIME_NONE, GST_MESSAGE_ERROR | GST_MESSAGE_EOS);

    // Parse message
    if (msg != NULL) {
        GError *err;
        gchar *debug_info;
        
        switch (GST_MESSAGE_TYPE(msg)) {
            case GST_MESSAGE_ERROR:
                gst_message_parse_error(msg, &err, &debug_info);
                g_printerr("Error received from element %s: %s\n", GST_OBJECT_NAME(msg->src), err->message);
                g_printerr("Debugging information: %s\n", debug_info);
                g_clear_error(&err);
                g_free(debug_info);
                break;
            case GST_MESSAGE_EOS:
                g_print("End-Of-Stream reached.\n");
                break;
            default:
                g_printerr("Unexpected message received.\n");
                break;
        }
        
        gst_message_unref(msg);
    }

    // Free resources
    gst_object_unref(bus);
    gst_element_set_state(pipeline, GST_STATE_NULL);
    gst_object_unref(pipeline);

    return 0;
}
